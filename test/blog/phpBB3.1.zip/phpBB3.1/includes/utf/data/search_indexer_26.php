<?php return array('힣'=>'힣');
