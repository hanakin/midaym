<?php
/******************************************************************************
    * POST SYNDICATION SCRIPT by chAos
    *
    * A very basic script that pulls threads with the first post from the database
    * and puts them into an array form so you can use them as you like.
    *
    * For use with phpBB3, freely distributable
    ******************************************************************************/

    /** Notes:
    * - Attachments haven't been handled properly.
    * - Starts a forum session as Guest user, taking all the default values for time, bbcode style (from theme), etc
    * - While viewing this page, users will appear to be viewing the Forum Index on viewonline.php.
    *   This can't be helped without modifying other code which is beyond this
    */

	define('FORUM_ID', 24);                    // Forum ID to get data from
	define('POST_LIMIT', 3);                  // How many to get
	define('PHPBB_ROOT_PATH', 'forum/');   // Path to phpBB (including trailing /)

	define('PRINT_TO_SCREEN', true);

	define('IN_PHPBB', true);
	$phpbb_root_path = PHPBB_ROOT_PATH;
	$phpEx = substr(strrchr(__FILE__, '.'), 1);
	global $db;

	// Grab user preferences
	$user->setup();

	$query =
	"SELECT u.user_id, u.username, t.topic_title, t.topic_poster, t.forum_id, t.topic_id, t.topic_time, t.topic_replies,
t.topic_first_post_id, p.poster_id, p.topic_id, p.post_id, p.post_text, p.bbcode_bitfield, p.bbcode_uid
	FROM ".USERS_TABLE." u, ".TOPICS_TABLE." t, ".POSTS_TABLE." p
	WHERE u.user_id = t.topic_poster
	AND u.user_id = p.poster_id
	AND t.topic_id = p.topic_id
	AND p.post_id = t.topic_first_post_id
	AND t.forum_id = ".FORUM_ID."
	ORDER BY t.topic_time DESC";

	$result = $db->sql_query_limit($query, POST_LIMIT);
	$posts = array();
	$news = array();
	$bbcode_bitfield = '';
	$message = '';
	$poster_id = 0;

	while ($r = $db->sql_fetchrow($result))
	{
		$posts[] = array(
		'topic_id' => $r['topic_id'],
			'topic_time' => $r['topic_time'],
			'username' => $r['username'],
			'user_id' => $r['user_id'],
			'topic_title' => $r['topic_title'],
			'post_text' => $r['post_text'],
			'bbcode_uid' => $r['bbcode_uid'],
			'bbcode_bitfield' => $r['bbcode_bitfield'],
			'topic_replies' => $r['topic_replies'],
			'topic_attachment' => $r['topic_attachment'],
			);
		$bbcode_bitfield = $bbcode_bitfield | base64_decode($r['bbcode_bitfield']);
    }


    // Instantiate BBCode
    if ($bbcode_bitfield !== '')
    {
       $bbcode = new bbcode(base64_encode($bbcode_bitfield));
    }

    // Output the posts
	foreach($posts as $m)
	{
		$poster_id = $m['user_id'];
       
		$message = $m['post_text'];
		if($m['bbcode_bitfield'])
		{
			$bbcode->bbcode_second_pass($message, $m['bbcode_uid'], $m['bbcode_bitfield']);
		}
		
		if($m['topic_attachment']==1)
		{
			$mysql = "SELECT real_filename FROM phpbb_attachments WHERE topic_id =".$posts['topic_id'];
			$result = $db->sql_query_limit($mysql, POST_LIMIT);
			$message = str_replace("<div class=\"inline-attachment\">", '<div class="inline-attachment"><a href="'.$result'"/>', $message);
			$message = str_replace(".rar</a>", '.rar', $message);
			$message = str_replace(".rar", '.rar</a>', $message);
		}
		
		$message = str_replace("\n", '<br />', $message);
		$message = smiley_text($message);

		$comment = ($m['topic_replies']==1) ? 'comment' : 'comments';
       

		echo "\n<div style='margin-bottom:32px; padding:6px 24px 12px 24px; background-color:#efefef; border:1px solid #e5e5e5;'>";
		echo "\n<h2><a href=\"".PHPBB_ROOT_PATH."viewtopic.php?f=".FORUM_ID."&amp;t={$m['topic_id']}\">{$m['topic_title']}</a></h3>";

		echo "\n<h4 class=\"postinfo\">on ".$user->format_date($m['topic_time'])." by <a href=\"".PHPBB_ROOT_PATH."memberlist.php?mode=viewprofile&u={$m['user_id']}\">{$m['username']}</a></h4>";

		echo "\n<br /><p style='padding:6px 6px;'>{$message}</p>";
		echo "\n<br /><br /><a style='float:right;' href=\"".PHPBB_ROOT_PATH."viewtopic.php?f=".FORUM_ID."&amp;t={$m['topic_id']}\">{$m['topic_replies']} {$comment}</a><br /><br />";
		echo "\n</div>";
       
		unset($message,$poster_id);
	}
?>
