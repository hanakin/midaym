<?php if (!defined('IN_PHPBB')) exit; ?><ol class="forums">
<?php $_forumrow_count = (isset($this->_tpldata['forumrow'])) ? sizeof($this->_tpldata['forumrow']) : 0;if ($_forumrow_count) {for ($_forumrow_i = 0; $_forumrow_i < $_forumrow_count; ++$_forumrow_i){$_forumrow_val = &$this->_tpldata['forumrow'][$_forumrow_i]; if (( $_forumrow_val['S_IS_CAT'] && ! $_forumrow_val['S_FIRST_ROW'] ) || $_forumrow_val['S_NO_CAT']) {  ?>

				</ol>
			</li>
		</ul>
	</li>
	<?php } if ($_forumrow_val['S_IS_CAT'] || $_forumrow_val['S_FIRST_ROW'] || $_forumrow_val['S_NO_CAT']) {  ?>

	<li class="forum gd2 rc5">
		<ul class="topiclist">
			<li class="hd">
				<dl class="clearfix">
					<dt class="title g8">
						<?php if ($_forumrow_val['S_IS_CAT']) {  ?>

						<a href="<?php echo $_forumrow_val['U_VIEWFORUM']; ?>"><?php echo $_forumrow_val['FORUM_NAME']; ?></a>
						<?php } else { ?>

						<?php echo ((isset($this->_rootref['L_FORUM'])) ? $this->_rootref['L_FORUM'] : ((isset($user->lang['FORUM'])) ? $user->lang['FORUM'] : '{ FORUM }')); ?>

						<?php } ?>

					</dt>
					<dd class="topics g2 omega"><?php echo ((isset($this->_rootref['L_TOPICS'])) ? $this->_rootref['L_TOPICS'] : ((isset($user->lang['TOPICS'])) ? $user->lang['TOPICS'] : '{ TOPICS }')); ?></dd>
					<dd class="posts g2 omega"><?php echo ((isset($this->_rootref['L_POSTS'])) ? $this->_rootref['L_POSTS'] : ((isset($user->lang['POSTS'])) ? $user->lang['POSTS'] : '{ POSTS }')); ?></dd>
					<dd class="latest g3"><?php echo ((isset($this->_rootref['L_LAST_POST'])) ? $this->_rootref['L_LAST_POST'] : ((isset($user->lang['LAST_POST'])) ? $user->lang['LAST_POST'] : '{ LAST_POST }')); ?></dd>
				</dl>
			</li>
			<li class="bd">
				<ol class="rows">
	<?php } if (! $_forumrow_val['S_IS_CAT']) {  ?>

					<li class="row clearfix">
						<dl class="clearfix">
							<dt class="icon<?php if ($_forumrow_val['FORUM_IMG_STYLE']) {  ?> <?php echo $_forumrow_val['FORUM_IMG_STYLE']; } ?>"><dfn><?php echo $_forumrow_val['FORUM_FOLDER_IMG_ALT']; ?></dfn></dt>
							<dt class="title g8 alpha">
								<div class="hgroup g15">
									<?php if ($this->_rootref['S_ENABLE_FEEDS'] && $_forumrow_val['S_FEED_ENABLED']) {  ?>

									<!-- <a class="feed-icon-forum" title="<?php echo ((isset($this->_rootref['L_FEED'])) ? $this->_rootref['L_FEED'] : ((isset($user->lang['FEED'])) ? $user->lang['FEED'] : '{ FEED }')); ?> - <?php echo $_forumrow_val['FORUM_NAME']; ?>" href="<?php echo (isset($this->_rootref['U_FEED'])) ? $this->_rootref['U_FEED'] : ''; ?>?f=<?php echo $_forumrow_val['FORUM_ID']; ?>"><img src="<?php echo (isset($this->_rootref['T_THEME_PATH'])) ? $this->_rootref['T_THEME_PATH'] : ''; ?>/images/feed.gif" alt="<?php echo ((isset($this->_rootref['L_FEED'])) ? $this->_rootref['L_FEED'] : ((isset($user->lang['FEED'])) ? $user->lang['FEED'] : '{ FEED }')); ?> - <?php echo $_forumrow_val['FORUM_NAME']; ?>" /></a> -->
									<?php } if ($_forumrow_val['FORUM_IMAGE']) {  ?>

									<span class="forum-image"><?php echo $_forumrow_val['FORUM_IMAGE']; ?></span>
									<?php } ?>

									<h3><a href="<?php echo $_forumrow_val['U_VIEWFORUM']; ?>" class="forumtitle"><?php echo $_forumrow_val['FORUM_NAME']; ?></a></h3>
									<p><?php echo $_forumrow_val['FORUM_DESC']; ?></p>
									<?php if ($_forumrow_val['MODERATORS']) {  ?>

									<dl class="mods clearfix">
										<dt><?php echo $_forumrow_val['L_MODERATOR_STR']; ?>&nbsp;</dt><dd><?php echo $_forumrow_val['MODERATORS']; ?></dd>
									</dl>
									<?php } if ($_forumrow_val['SUBFORUMS'] && $_forumrow_val['S_LIST_SUBFORUMS']) {  ?>

									<dl class="subs clearfix">
										<dt><?php echo $_forumrow_val['L_SUBFORUM_STR']; ?>&nbsp;</dt><dd><?php echo $_forumrow_val['SUBFORUMS']; ?></dd>
									</dl>
									<?php } ?>

							 	</div>
							</dt>
							<?php if ($_forumrow_val['CLICKS']) {  ?>

							<dd class="redirect g2 alpha omega"><span><?php echo ((isset($this->_rootref['L_REDIRECTS'])) ? $this->_rootref['L_REDIRECTS'] : ((isset($user->lang['REDIRECTS'])) ? $user->lang['REDIRECTS'] : '{ REDIRECTS }')); ?>: <?php echo $_forumrow_val['CLICKS']; ?></span></dd>
							<?php } else if (! $_forumrow_val['S_IS_LINK']) {  ?>

							<dd class="topics g2 alpha omega"><?php echo $_forumrow_val['TOPICS']; ?> <dfn><?php echo ((isset($this->_rootref['L_TOPICS'])) ? $this->_rootref['L_TOPICS'] : ((isset($user->lang['TOPICS'])) ? $user->lang['TOPICS'] : '{ TOPICS }')); ?></dfn></dd>
							<dd class="posts g2 alpha omega"><?php echo $_forumrow_val['POSTS']; ?> <dfn><?php echo ((isset($this->_rootref['L_POSTS'])) ? $this->_rootref['L_POSTS'] : ((isset($user->lang['POSTS'])) ? $user->lang['POSTS'] : '{ POSTS }')); ?></dfn></dd>
							<dd class="latest g3 alpha">
								<?php if ($_forumrow_val['U_UNAPPROVED_TOPICS']) {  ?>

								<span class="unapproved">
									<a class="unapproved-icon" href="<?php echo $_forumrow_val['U_UNAPPROVED_TOPICS']; ?>"><?php echo (isset($this->_rootref['UNAPPROVED_IMG'])) ? $this->_rootref['UNAPPROVED_IMG'] : ''; ?></a> 
								</span>
								<?php } if ($_forumrow_val['LAST_POST_TIME']) {  ?>

								<cite<?php if ($_forumrow_val['U_UNAPPROVED_TOPICS']) {  ?> class="unapproved"<?php } ?>>
									<span>
										<dfn><?php echo ((isset($this->_rootref['L_LAST_POST'])) ? $this->_rootref['L_LAST_POST'] : ((isset($user->lang['LAST_POST'])) ? $user->lang['LAST_POST'] : '{ LAST_POST }')); ?></dfn> <?php echo ((isset($this->_rootref['L_POST_BY_AUTHOR'])) ? $this->_rootref['L_POST_BY_AUTHOR'] : ((isset($user->lang['POST_BY_AUTHOR'])) ? $user->lang['POST_BY_AUTHOR'] : '{ POST_BY_AUTHOR }')); ?> <?php echo $_forumrow_val['LAST_POSTER_FULL']; ?>

										<?php if (! $this->_rootref['S_IS_BOT']) {  ?>

									 	<a class="latestpost-icon" href="<?php echo $_forumrow_val['U_LAST_POST']; ?>">View the latest post</a> 
										<?php } ?>

									</span>
									<span class="time"><?php echo $_forumrow_val['LAST_POST_TIME']; ?></span>
								</cite>
								<?php } else { ?>

								<span><?php echo ((isset($this->_rootref['L_NO_POSTS'])) ? $this->_rootref['L_NO_POSTS'] : ((isset($user->lang['NO_POSTS'])) ? $user->lang['NO_POSTS'] : '{ NO_POSTS }')); ?></span>
								<?php } ?>

							</dd>
							<?php } ?>

						</dl>
					</li>
	<?php } if ($_forumrow_val['S_LAST_ROW']) {  ?>

  				</ol>
  			</li>
  		</ul>
  	</li>
  <?php } }} else { ?>

<div class="section rc5 bg1">
	<div class="article clearfix">
		<strong><?php echo ((isset($this->_rootref['L_NO_FORUMS'])) ? $this->_rootref['L_NO_FORUMS'] : ((isset($user->lang['NO_FORUMS'])) ? $user->lang['NO_FORUMS'] : '{ NO_FORUMS }')); ?></strong>
	</div>
</div>
<?php } ?>

</ol>