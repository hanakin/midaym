<?php if (!defined('IN_PHPBB')) exit; $this->_tpl_include('includes/overall_header.html'); ?>


<h2><a href="<?php echo (isset($this->_rootref['U_VIEW_TOPIC'])) ? $this->_rootref['U_VIEW_TOPIC'] : ''; ?>"><?php echo (isset($this->_rootref['TOPIC_TITLE'])) ? $this->_rootref['TOPIC_TITLE'] : ''; ?></a></h2>
<?php if ($this->_rootref['FORUM_DESC'] || $this->_rootref['MODERATORS'] || $this->_rootref['U_MCP']) {  ?>

<div id="desc" class="section desc">
	<!-- NOTE: remove the class="hide" you want to have the forum description on the forum body --><?php if ($this->_rootref['FORUM_DESC']) {  ?>

	<p class="hide"><?php echo (isset($this->_rootref['FORUM_DESC'])) ? $this->_rootref['FORUM_DESC'] : ''; ?></p>
	<?php } if ($this->_rootref['MODERATORS']) {  ?>

	<dl class="clearfix">
		<dt>
			<?php if ($this->_rootref['S_SINGLE_MODERATOR']) {  ?>

			<?php echo ((isset($this->_rootref['L_MODERATOR'])) ? $this->_rootref['L_MODERATOR'] : ((isset($user->lang['MODERATOR'])) ? $user->lang['MODERATOR'] : '{ MODERATOR }')); ?>

			<?php } else { ?>

			<?php echo ((isset($this->_rootref['L_MODERATORS'])) ? $this->_rootref['L_MODERATORS'] : ((isset($user->lang['MODERATORS'])) ? $user->lang['MODERATORS'] : '{ MODERATORS }')); ?>

			<?php } ?>: 
		</dt>
		<dd><?php echo (isset($this->_rootref['MODERATORS'])) ? $this->_rootref['MODERATORS'] : ''; ?></dd>
	</dl>	
	<?php } ?>

</div>
<?php } if ($this->_rootref['S_FORUM_RULES']) {  ?>

<div id="rules" class="section rules rc5 bg4">
	<div class="article clearfix">
		<?php if ($this->_rootref['U_FORUM_RULES']) {  ?>

		<a href="<?php echo (isset($this->_rootref['U_FORUM_RULES'])) ? $this->_rootref['U_FORUM_RULES'] : ''; ?>"><?php echo ((isset($this->_rootref['L_FORUM_RULES'])) ? $this->_rootref['L_FORUM_RULES'] : ((isset($user->lang['FORUM_RULES'])) ? $user->lang['FORUM_RULES'] : '{ FORUM_RULES }')); ?></a>
		<?php } else { ?>

		<h3><?php echo ((isset($this->_rootref['L_FORUM_RULES'])) ? $this->_rootref['L_FORUM_RULES'] : ((isset($user->lang['FORUM_RULES'])) ? $user->lang['FORUM_RULES'] : '{ FORUM_RULES }')); ?></h3>
		<p><?php echo (isset($this->_rootref['FORUM_RULES'])) ? $this->_rootref['FORUM_RULES'] : ''; ?></p>
		<?php } ?>

	</div>
</div>
<?php } if ($this->_rootref['S_DISPLAY_POST_INFO'] || $this->_rootref['PAGINATION'] || $this->_rootref['TOTAL_POSTS'] || $this->_rootref['TOTAL_TOPICS']) {  ?>

<ul class="topic-actions clearfix">
	<?php if (! $this->_rootref['S_IS_BOT'] && $this->_rootref['S_DISPLAY_POST_INFO']) {  ?>

	<li class="lt">
		<span class="forumbutton rc5"><a class="gd3 rc5" href="<?php echo (isset($this->_rootref['U_POST_REPLY_TOPIC'])) ? $this->_rootref['U_POST_REPLY_TOPIC'] : ''; ?>" title="<?php if ($this->_rootref['S_IS_LOCKED']) {  echo ((isset($this->_rootref['L_TOPIC_LOCKED'])) ? $this->_rootref['L_TOPIC_LOCKED'] : ((isset($user->lang['TOPIC_LOCKED'])) ? $user->lang['TOPIC_LOCKED'] : '{ TOPIC_LOCKED }')); } else { echo ((isset($this->_rootref['L_POST_REPLY'])) ? $this->_rootref['L_POST_REPLY'] : ((isset($user->lang['POST_REPLY'])) ? $user->lang['POST_REPLY'] : '{ POST_REPLY }')); } ?>"><span><?php if ($this->_rootref['S_IS_LOCKED']) {  ?><strong>Locked</strong><?php } else { ?>Post<strong>Reply</strong><?php } ?></span></a></span>
	</li>
	<?php } if ($this->_rootref['S_DISPLAY_SEARCHBOX']) {  ?><!-- #NOTE why do we need this here if its displayed globaly in the header nav -->
	<li class="cn">
		<form action="<?php echo (isset($this->_rootref['U_SEARCH'])) ? $this->_rootref['U_SEARCH'] : ''; ?>" method="get" id="search">
			<fieldset>
				<input id="field" class="search rc20" name="keywords" type="text" value="<?php echo ((isset($this->_rootref['L_SEARCH_FORUM'])) ? $this->_rootref['L_SEARCH_FORUM'] : ((isset($user->lang['SEARCH_FORUM'])) ? $user->lang['SEARCH_FORUM'] : '{ SEARCH_FORUM }')); ?>" />
				<input class="button2" value="Search" type="submit" />
				<input type="hidden" value="<?php echo (isset($this->_rootref['FORUM_ID'])) ? $this->_rootref['FORUM_ID'] : ''; ?>" name="fid[]" />
			</fieldset>
		</form>
	</li>
	<?php } if ($this->_rootref['PAGINATION'] || $this->_rootref['TOTAL_POSTS'] || $this->_rootref['TOTAL_TOPICS']) {  ?>

	<li class="rt">
		<ul class="paging nav list">
			<?php if (! $this->_rootref['S_IS_BOT'] && $this->_rootref['U_MARK_TOPICS']) {  ?>

			<li><a href="<?php echo (isset($this->_rootref['U_MARK_TOPICS'])) ? $this->_rootref['U_MARK_TOPICS'] : ''; ?>" accesskey="m"><?php echo ((isset($this->_rootref['L_MARK_TOPICS_READ'])) ? $this->_rootref['L_MARK_TOPICS_READ'] : ((isset($user->lang['MARK_TOPICS_READ'])) ? $user->lang['MARK_TOPICS_READ'] : '{ MARK_TOPICS_READ }')); ?></a>
			<?php } if ($this->_rootref['TOTAL_TOPICS']) {  ?>

			<li><?php echo (isset($this->_rootref['TOTAL_TOPICS'])) ? $this->_rootref['TOTAL_TOPICS'] : ''; ?></li>
			<?php } if ($this->_rootref['PAGE_NUMBER']) {  if ($this->_rootref['PAGINATION']) {  ?>

			<li><a href="#" class="jumpto" title="<?php echo ((isset($this->_rootref['L_JUMP_TO_PAGE'])) ? $this->_rootref['L_JUMP_TO_PAGE'] : ((isset($user->lang['JUMP_TO_PAGE'])) ? $user->lang['JUMP_TO_PAGE'] : '{ JUMP_TO_PAGE }')); ?>"><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></a></li>
			<li class="pages"><?php echo (isset($this->_rootref['PAGINATION'])) ? $this->_rootref['PAGINATION'] : ''; ?></li><!-- this needs rewritten into a list or separated into a loop --><?php } else { ?>

			<li><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></li>
				<?php } } ?>

		</ul>
	</li>
	<?php } ?>

</ul>
<?php } if ($this->_rootref['S_HAS_POLL']) {  $this->_tpl_include('includes/poll.inc.html'); } ?>

<ol id="posts" class="posts">
<?php $_postrow_count = (isset($this->_tpldata['postrow'])) ? sizeof($this->_tpldata['postrow']) : 0;if ($_postrow_count) {for ($_postrow_i = 0; $_postrow_i < $_postrow_count; ++$_postrow_i){$_postrow_val = &$this->_tpldata['postrow'][$_postrow_i]; if ($_postrow_val['S_FIRST_UNREAD']) {  ?>

	<a id="unread"></a>
	<?php } ?>

	<li id="postrow<?php echo $_postrow_val['POST_ID']; ?>" class="section post<?php if ($_postrow_val['S_UNREAD_POST']) {  ?> unreadpost<?php } if ($_postrow_val['S_FIRST_ROW']) {  ?> first<?php } if ($_postrow_val['S_POST_REPORTED']) {  ?> reported<?php } if ($_postrow_val['S_ONLINE'] && ! $_postrow_val['S_IGNORE_POST']) {  ?> online<?php } ?> rc5">
		<div class="article clearfix">
			<div id="post<?php echo $_postrow_val['POST_ID']; ?>" class="aside lt postbody g13">
				<?php if ($_postrow_val['S_IGNORE_POST']) {  ?>

				<p class="hd ignore"><?php echo $_postrow_val['L_IGNORE_POST']; ?></p>
				<?php } else { ?>	
				<div class="hgroup hd clearfix">
					<div class="aside lt">
						<h3 <?php if ($_postrow_val['S_FIRST_ROW']) {  ?>class="first"<?php } ?>>
							<?php if ($_postrow_val['POST_ICON_IMG']) {  ?>

							<img src="<?php echo (isset($this->_rootref['T_ICONS_PATH'])) ? $this->_rootref['T_ICONS_PATH'] : ''; echo $_postrow_val['POST_ICON_IMG']; ?>" width="<?php echo $_postrow_val['POST_ICON_IMG_WIDTH']; ?>" height="<?php echo $_postrow_val['POST_ICON_IMG_HEIGHT']; ?>" alt="" /> 
							<?php } ?>

							<a href="#p<?php echo $_postrow_val['POST_ID']; ?>"><?php echo $_postrow_val['POST_SUBJECT']; ?></a>
						</h3>
						<cite>
							<span>
								<a class="post-icon" href="<?php echo $_postrow_val['U_MINI_POST']; ?>">Post</a> <?php echo ((isset($this->_rootref['L_POST_BY_AUTHOR'])) ? $this->_rootref['L_POST_BY_AUTHOR'] : ((isset($user->lang['POST_BY_AUTHOR'])) ? $user->lang['POST_BY_AUTHOR'] : '{ POST_BY_AUTHOR }')); ?> <strong><?php echo $_postrow_val['POST_AUTHOR_FULL']; ?></strong> &raquo; 
							</span>
							<span class="time"><?php echo $_postrow_val['POST_DATE']; ?></span>
						</cite>
					</div>
					<div class="aside rt">
						<?php if (! $this->_rootref['S_IS_BOT']) {  if ($_postrow_val['U_EDIT'] || $_postrow_val['U_DELETE'] || $_postrow_val['U_REPORT'] || $_postrow_val['U_WARN'] || $_postrow_val['U_INFO'] || $_postrow_val['U_QUOTE']) {  ?>

							<ul class="post-icons nav list clearfix">
								<?php if ($_postrow_val['U_EDIT']) {  ?>

								<li class="edit-icon"><a href="<?php echo $_postrow_val['U_EDIT']; ?>" title="<?php echo ((isset($this->_rootref['L_EDIT_POST'])) ? $this->_rootref['L_EDIT_POST'] : ((isset($user->lang['EDIT_POST'])) ? $user->lang['EDIT_POST'] : '{ EDIT_POST }')); ?>"><?php echo ((isset($this->_rootref['L_EDIT_POST'])) ? $this->_rootref['L_EDIT_POST'] : ((isset($user->lang['EDIT_POST'])) ? $user->lang['EDIT_POST'] : '{ EDIT_POST }')); ?></a></li>
								<?php } if ($_postrow_val['U_DELETE']) {  ?>

								<li class="delete-icon"><a href="<?php echo $_postrow_val['U_DELETE']; ?>" title="<?php echo ((isset($this->_rootref['L_DELETE_POST'])) ? $this->_rootref['L_DELETE_POST'] : ((isset($user->lang['DELETE_POST'])) ? $user->lang['DELETE_POST'] : '{ DELETE_POST }')); ?>"><?php echo ((isset($this->_rootref['L_DELETE_POST'])) ? $this->_rootref['L_DELETE_POST'] : ((isset($user->lang['DELETE_POST'])) ? $user->lang['DELETE_POST'] : '{ DELETE_POST }')); ?></a></li>
								<?php } if ($_postrow_val['U_REPORT']) {  ?>

								<li class="report-icon"><a href="<?php echo $_postrow_val['U_REPORT']; ?>" title="<?php echo ((isset($this->_rootref['L_REPORT_POST'])) ? $this->_rootref['L_REPORT_POST'] : ((isset($user->lang['REPORT_POST'])) ? $user->lang['REPORT_POST'] : '{ REPORT_POST }')); ?>"><?php echo ((isset($this->_rootref['L_REPORT_POST'])) ? $this->_rootref['L_REPORT_POST'] : ((isset($user->lang['REPORT_POST'])) ? $user->lang['REPORT_POST'] : '{ REPORT_POST }')); ?></a></li>
								<?php } if ($_postrow_val['U_WARN']) {  ?>

								<li class="warn-icon"><a href="<?php echo $_postrow_val['U_WARN']; ?>" title="<?php echo ((isset($this->_rootref['L_WARN_USER'])) ? $this->_rootref['L_WARN_USER'] : ((isset($user->lang['WARN_USER'])) ? $user->lang['WARN_USER'] : '{ WARN_USER }')); ?>"><?php echo ((isset($this->_rootref['L_WARN_USER'])) ? $this->_rootref['L_WARN_USER'] : ((isset($user->lang['WARN_USER'])) ? $user->lang['WARN_USER'] : '{ WARN_USER }')); ?></a></li>
								<?php } if ($_postrow_val['U_INFO']) {  ?>

								<li class="info-icon"><a href="<?php echo $_postrow_val['U_INFO']; ?>" title="<?php echo ((isset($this->_rootref['L_INFORMATION'])) ? $this->_rootref['L_INFORMATION'] : ((isset($user->lang['INFORMATION'])) ? $user->lang['INFORMATION'] : '{ INFORMATION }')); ?>"><?php echo ((isset($this->_rootref['L_INFORMATION'])) ? $this->_rootref['L_INFORMATION'] : ((isset($user->lang['INFORMATION'])) ? $user->lang['INFORMATION'] : '{ INFORMATION }')); ?></a></li>
								<?php } if ($_postrow_val['U_QUOTE']) {  ?>

								<li class="quote-icon"><a href="<?php echo $_postrow_val['U_QUOTE']; ?>" title="<?php echo ((isset($this->_rootref['L_REPLY_WITH_QUOTE'])) ? $this->_rootref['L_REPLY_WITH_QUOTE'] : ((isset($user->lang['REPLY_WITH_QUOTE'])) ? $user->lang['REPLY_WITH_QUOTE'] : '{ REPLY_WITH_QUOTE }')); ?>"><?php echo ((isset($this->_rootref['L_REPLY_WITH_QUOTE'])) ? $this->_rootref['L_REPLY_WITH_QUOTE'] : ((isset($user->lang['REPLY_WITH_QUOTE'])) ? $user->lang['REPLY_WITH_QUOTE'] : '{ REPLY_WITH_QUOTE }')); ?></a></li>
								<?php } ?>

							</ul>
							<?php } } ?>

					</div>
				</div>
				<div class="bd clearfix">
					<?php if ($_postrow_val['S_POST_UNAPPROVED'] || $_postrow_val['S_POST_REPORTED']) {  ?>

					<p class="rules bg4">
						<?php if ($_postrow_val['S_POST_UNAPPROVED']) {  ?>

						<a class="unapproved-icon" href="<?php echo $_postrow_val['U_MCP_APPROVE']; ?>"><strong>This post is waiting for approval</strong></a>
						<?php } if ($_postrow_val['S_POST_REPORTED']) {  ?>

						<a  class="reported-icon" href="<?php echo $_postrow_val['U_MCP_REPORT']; ?>"><strong><?php echo ((isset($this->_rootref['L_POST_REPORTED'])) ? $this->_rootref['L_POST_REPORTED'] : ((isset($user->lang['POST_REPORTED'])) ? $user->lang['POST_REPORTED'] : '{ POST_REPORTED }')); ?></strong></a>
						<?php } ?>

					</p>
					<?php } ?>

					<div class="message"><?php echo $_postrow_val['MESSAGE']; ?></div>
					<?php if ($_postrow_val['S_HAS_ATTACHMENTS']) {  ?>

					<pre class="attachment">
						<h4><?php echo ((isset($this->_rootref['L_ATTACHMENTS'])) ? $this->_rootref['L_ATTACHMENTS'] : ((isset($user->lang['ATTACHMENTS'])) ? $user->lang['ATTACHMENTS'] : '{ ATTACHMENTS }')); ?></h4>
						<?php $_attachment_count = (isset($_postrow_val['attachment'])) ? sizeof($_postrow_val['attachment']) : 0;if ($_attachment_count) {for ($_attachment_i = 0; $_attachment_i < $_attachment_count; ++$_attachment_i){$_attachment_val = &$_postrow_val['attachment'][$_attachment_i]; ?>

						<?php echo $_attachment_val['DISPLAY_ATTACHMENT']; ?>

						<?php }} ?>

					</pre>
					<?php } ?>

				</div>
				<div class="ft">
					<ul>
						<?php if ($_postrow_val['S_DISPLAY_NOTICE']) {  ?>

						<li class="donwloaded">
							<p class="rules"><?php echo ((isset($this->_rootref['L_DOWNLOAD_NOTICE'])) ? $this->_rootref['L_DOWNLOAD_NOTICE'] : ((isset($user->lang['DOWNLOAD_NOTICE'])) ? $user->lang['DOWNLOAD_NOTICE'] : '{ DOWNLOAD_NOTICE }')); ?></p>
						</li>
						<?php } if ($_postrow_val['EDITED_MESSAGE'] || $_postrow_val['EDIT_REASON']) {  ?>

						<li class="edited">
							<cite><?php echo $_postrow_val['EDITED_MESSAGE']; ?></cite> <!-- #NOTE edit backend for proper semantics --><?php if ($_postrow_val['EDIT_REASON']) {  ?>

							<dfn><strong><?php echo ((isset($this->_rootref['L_REASON'])) ? $this->_rootref['L_REASON'] : ((isset($user->lang['REASON'])) ? $user->lang['REASON'] : '{ REASON }')); ?>:</strong> <em><?php echo $_postrow_val['EDIT_REASON']; ?></em></dfn>
							<?php } ?>

						</li>
						<?php } if ($_postrow_val['BUMPED_MESSAGE']) {  ?>

						<li class="bumped">
							<p><?php echo $_postrow_val['BUMPED_MESSAGE']; ?></p>
						</li>
						<?php } if ($_postrow_val['SIGNATURE']) {  ?>

						<li class="signature" id="sig<?php echo $_postrow_val['POST_ID']; ?>">
							<?php echo $_postrow_val['SIGNATURE']; ?>

						</li>
						<?php } ?>

					</ul>
				</div>
			</div>
			<div id="profile<?php echo $_postrow_val['POST_ID']; ?>" class="aside rt profile g3 omega">
				<?php if (! $_postrow_val['S_IGNORE_POST']) {  ?>

				<span class="postprofile">
					<?php if ($_postrow_val['POSTER_AVATAR']) {  ?>

					<dl class="clearfix">
						<dd><?php echo $_postrow_val['POSTER_AVATAR']; ?></dd>
					</dl>
					<?php } if (! $_postrow_val['U_POST_AUTHOR']) {  ?>

					<dl class="clearfix">
						<dd><strong><?php echo $_postrow_val['POST_AUTHOR_FULL']; ?></strong></dd>
					</dl>
					<?php } else { ?>

					<dl class="clearfix">
						<dd><?php echo $_postrow_val['POST_AUTHOR_FULL']; ?></dd>
					</dl>
					<?php } ?>

					<dl class="clearfix">
					<?php if ($_postrow_val['RANK_IMG']) {  ?>

						<dd><?php echo $_postrow_val['RANK_IMG']; ?></dd>
					<?php } else { ?>

						<dd><?php echo $_postrow_val['RANK_TITLE']; ?></dd>
					<?php } ?>

					</dl>
					<dl class="clearfix">
						<dd>&nbsp;</dd>
					</dl>
					<?php if ($_postrow_val['POSTER_POSTS'] != ('')) {  ?>

					<dl class="details clearfix">
						<dt><?php echo ((isset($this->_rootref['L_POSTS'])) ? $this->_rootref['L_POSTS'] : ((isset($user->lang['POSTS'])) ? $user->lang['POSTS'] : '{ POSTS }')); ?>: </dt><dd><?php echo $_postrow_val['POSTER_POSTS']; ?></dd>
					</dl>
					<?php } if ($_postrow_val['POSTER_JOINED']) {  ?>

					<dl class="details clearfix">
						<dt><?php echo ((isset($this->_rootref['L_JOINED'])) ? $this->_rootref['L_JOINED'] : ((isset($user->lang['JOINED'])) ? $user->lang['JOINED'] : '{ JOINED }')); ?>: </dt><dd><?php echo $_postrow_val['POSTER_JOINED']; ?></dd>
					</dl>
					<?php } if ($_postrow_val['POSTER_FROM']) {  ?>

					<dl class="details clearfix">
						<dt><?php echo ((isset($this->_rootref['L_LOCATION'])) ? $this->_rootref['L_LOCATION'] : ((isset($user->lang['LOCATION'])) ? $user->lang['LOCATION'] : '{ LOCATION }')); ?>: </dt><dd><?php echo $_postrow_val['POSTER_FROM']; ?></dd>
					</dl>
					<?php } if ($_postrow_val['S_PROFILE_FIELD1']) {  ?><!-- Use a construct like this to include admin defined profile fields. Replace FIELD1 with the name of your field. -->
					<dl class="details clearfix">
						<dt><?php echo $_postrow_val['PROFILE_FIELD1_NAME']; ?>: </dt><dd><?php echo $_postrow_val['PROFILE_FIELD1_VALUE']; ?></dd>
					</dl>
					<?php } $_custom_fields_count = (isset($_postrow_val['custom_fields'])) ? sizeof($_postrow_val['custom_fields']) : 0;if ($_custom_fields_count) {for ($_custom_fields_i = 0; $_custom_fields_i < $_custom_fields_count; ++$_custom_fields_i){$_custom_fields_val = &$_postrow_val['custom_fields'][$_custom_fields_i]; ?>

					<dl class="details clearfix">
						<dt><?php echo $_custom_fields_val['PROFILE_FIELD_NAME']; ?>: </dt><dd><?php echo $_custom_fields_val['PROFILE_FIELD_VALUE']; ?></dd>
					</dl>
					<?php }} if (! $this->_rootref['S_IS_BOT']) {  if ($_postrow_val['U_PM'] || $_postrow_val['U_EMAIL'] || $_postrow_val['U_WWW'] || $_postrow_val['U_MSN'] || $_postrow_val['U_ICQ'] || $_postrow_val['U_YIM'] || $_postrow_val['U_AIM'] || $_postrow_val['U_JABBER']) {  ?>

					<dl class="clearfix">
						<dd>
							<ul class="profile-icons nav list">
								<?php if ($_postrow_val['U_PM']) {  ?>

								<li class="pm-icon"><a href="<?php echo $_postrow_val['U_PM']; ?>" title="<?php echo ((isset($this->_rootref['L_PRIVATE_MESSAGE'])) ? $this->_rootref['L_PRIVATE_MESSAGE'] : ((isset($user->lang['PRIVATE_MESSAGE'])) ? $user->lang['PRIVATE_MESSAGE'] : '{ PRIVATE_MESSAGE }')); ?>"><?php echo ((isset($this->_rootref['L_PRIVATE_MESSAGE'])) ? $this->_rootref['L_PRIVATE_MESSAGE'] : ((isset($user->lang['PRIVATE_MESSAGE'])) ? $user->lang['PRIVATE_MESSAGE'] : '{ PRIVATE_MESSAGE }')); ?></a></li>
								<?php } if ($_postrow_val['U_EMAIL']) {  ?>

								<li class="email-icon"><a href="<?php echo $_postrow_val['U_EMAIL']; ?>" title="<?php echo ((isset($this->_rootref['L_SEND_EMAIL_USER'])) ? $this->_rootref['L_SEND_EMAIL_USER'] : ((isset($user->lang['SEND_EMAIL_USER'])) ? $user->lang['SEND_EMAIL_USER'] : '{ SEND_EMAIL_USER }')); ?> <?php echo $_postrow_val['POST_AUTHOR']; ?>"><?php echo ((isset($this->_rootref['L_SEND_EMAIL_USER'])) ? $this->_rootref['L_SEND_EMAIL_USER'] : ((isset($user->lang['SEND_EMAIL_USER'])) ? $user->lang['SEND_EMAIL_USER'] : '{ SEND_EMAIL_USER }')); ?> <?php echo $_postrow_val['POST_AUTHOR']; ?></a></li>
								<?php } if ($_postrow_val['U_WWW']) {  ?>

								<li class="web-icon"><a href="<?php echo $_postrow_val['U_WWW']; ?>" title="<?php echo ((isset($this->_rootref['L_VISIT_WEBSITE'])) ? $this->_rootref['L_VISIT_WEBSITE'] : ((isset($user->lang['VISIT_WEBSITE'])) ? $user->lang['VISIT_WEBSITE'] : '{ VISIT_WEBSITE }')); ?>: <?php echo $_postrow_val['U_WWW']; ?>"><?php echo ((isset($this->_rootref['L_WEBSITE'])) ? $this->_rootref['L_WEBSITE'] : ((isset($user->lang['WEBSITE'])) ? $user->lang['WEBSITE'] : '{ WEBSITE }')); ?></a></li>
								<?php } if ($_postrow_val['U_MSN']) {  ?>

								<li class="msnm-icon"><a href="<?php echo $_postrow_val['U_MSN']; ?>" class="msnm" title="<?php echo ((isset($this->_rootref['L_MSNM'])) ? $this->_rootref['L_MSNM'] : ((isset($user->lang['MSNM'])) ? $user->lang['MSNM'] : '{ MSNM }')); ?>"><?php echo ((isset($this->_rootref['L_MSNM'])) ? $this->_rootref['L_MSNM'] : ((isset($user->lang['MSNM'])) ? $user->lang['MSNM'] : '{ MSNM }')); ?></a></li>
								<?php } if ($_postrow_val['U_ICQ']) {  ?>

								<li class="icq-icon"><a href="<?php echo $_postrow_val['U_ICQ']; ?>" class="icq" title="<?php echo ((isset($this->_rootref['L_ICQ'])) ? $this->_rootref['L_ICQ'] : ((isset($user->lang['ICQ'])) ? $user->lang['ICQ'] : '{ ICQ }')); ?>"><?php echo ((isset($this->_rootref['L_ICQ'])) ? $this->_rootref['L_ICQ'] : ((isset($user->lang['ICQ'])) ? $user->lang['ICQ'] : '{ ICQ }')); ?></a></li>
								<?php } if ($_postrow_val['U_YIM']) {  ?>

								<li class="yahoo-icon"><a href="<?php echo $_postrow_val['U_YIM']; ?>" class="yim" title="<?php echo ((isset($this->_rootref['L_YIM'])) ? $this->_rootref['L_YIM'] : ((isset($user->lang['YIM'])) ? $user->lang['YIM'] : '{ YIM }')); ?>"><?php echo ((isset($this->_rootref['L_YIM'])) ? $this->_rootref['L_YIM'] : ((isset($user->lang['YIM'])) ? $user->lang['YIM'] : '{ YIM }')); ?></a></li>
								<?php } if ($_postrow_val['U_AIM']) {  ?>

								<li class="aim-icon"><a href="<?php echo $_postrow_val['U_AIM']; ?>" class="aim" title="<?php echo ((isset($this->_rootref['L_AIM'])) ? $this->_rootref['L_AIM'] : ((isset($user->lang['AIM'])) ? $user->lang['AIM'] : '{ AIM }')); ?>"><?php echo ((isset($this->_rootref['L_AIM'])) ? $this->_rootref['L_AIM'] : ((isset($user->lang['AIM'])) ? $user->lang['AIM'] : '{ AIM }')); ?></a></li>
								<?php } if ($_postrow_val['U_JABBER']) {  ?>

								<li class="jabber-icon"><a href="<?php echo $_postrow_val['U_JABBER']; ?>" class="jabber" title="<?php echo ((isset($this->_rootref['L_JABBER'])) ? $this->_rootref['L_JABBER'] : ((isset($user->lang['JABBER'])) ? $user->lang['JABBER'] : '{ JABBER }')); ?>"><?php echo ((isset($this->_rootref['L_JABBER'])) ? $this->_rootref['L_JABBER'] : ((isset($user->lang['JABBER'])) ? $user->lang['JABBER'] : '{ JABBER }')); ?></a></li>
								<?php } ?>

							</ul>
						</dd>
					</dl>	
						<?php } } ?>

				</span>
				<?php } ?>

			</div>
			<?php } if ($_postrow_val['S_IGNORE_POST']) {  } else { ?>

			<span class="back2top rt clearfix"><a href="#top" class="top" title="<?php echo ((isset($this->_rootref['L_BACK_TO_TOP'])) ? $this->_rootref['L_BACK_TO_TOP'] : ((isset($user->lang['BACK_TO_TOP'])) ? $user->lang['BACK_TO_TOP'] : '{ BACK_TO_TOP }')); ?>"><?php echo ((isset($this->_rootref['L_BACK_TO_TOP'])) ? $this->_rootref['L_BACK_TO_TOP'] : ((isset($user->lang['BACK_TO_TOP'])) ? $user->lang['BACK_TO_TOP'] : '{ BACK_TO_TOP }')); ?></a></span>
			<?php } ?>

		</div>
	</li>
	<hr class="divider" />
<?php }} ?>

</ol>
<?php if ($this->_rootref['S_QUICK_REPLY']) {  $this->_tpldata['DEFINE']['.']['QUICK_REPLY'] = 1; $this->_tpl_include('includes/quickreply_editor.html'); } if ($this->_rootref['S_NUM_POSTS'] > (1) || $this->_rootref['PREVIOUS_PAGE']) {  ?>

<form method="post" action="<?php echo (isset($this->_rootref['S_TOPIC_ACTION'])) ? $this->_rootref['S_TOPIC_ACTION'] : ''; ?>">
	<ul class="display-options clearfix">
		<li class="lt prev g1 alpha">
			<?php if ($this->_rootref['PREVIOUS_PAGE']) {  ?>

			<a href="<?php echo (isset($this->_rootref['PREVIOUS_PAGE'])) ? $this->_rootref['PREVIOUS_PAGE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_PREVIOUS'])) ? $this->_rootref['L_PREVIOUS'] : ((isset($user->lang['PREVIOUS'])) ? $user->lang['PREVIOUS'] : '{ PREVIOUS }')); ?></a>
			<?php } else { ?>

			&nbsp;
			<?php } ?>

		</li>
		<li class="cn g14">
			<?php if (! $this->_rootref['S_IS_BOT']) {  ?>

			<fieldset>
				<dl class="clearfix">
					<dt><label><?php echo ((isset($this->_rootref['L_DISPLAY_POSTS'])) ? $this->_rootref['L_DISPLAY_POSTS'] : ((isset($user->lang['DISPLAY_POSTS'])) ? $user->lang['DISPLAY_POSTS'] : '{ DISPLAY_POSTS }')); ?>: </label></dt>
					<dd><?php echo (isset($this->_rootref['S_SELECT_SORT_DAYS'])) ? $this->_rootref['S_SELECT_SORT_DAYS'] : ''; ?></dd>
					<dt><label><?php echo ((isset($this->_rootref['L_SORT_BY'])) ? $this->_rootref['L_SORT_BY'] : ((isset($user->lang['SORT_BY'])) ? $user->lang['SORT_BY'] : '{ SORT_BY }')); ?> </label></dt><dd><?php echo (isset($this->_rootref['S_SELECT_SORT_KEY'])) ? $this->_rootref['S_SELECT_SORT_KEY'] : ''; ?></dd>
					<dd><?php echo (isset($this->_rootref['S_SELECT_SORT_DIR'])) ? $this->_rootref['S_SELECT_SORT_DIR'] : ''; ?></dd>
					<dd><input type="submit" name="sort" value="<?php echo ((isset($this->_rootref['L_GO'])) ? $this->_rootref['L_GO'] : ((isset($user->lang['GO'])) ? $user->lang['GO'] : '{ GO }')); ?>" class="button2" /></dd>
				</dl>
			</fieldset>
			<?php } ?>

		</li>
		<li class="rt next g1 omega">	
			<?php if ($this->_rootref['NEXT_PAGE']) {  ?>

			<a href="<?php echo (isset($this->_rootref['NEXT_PAGE'])) ? $this->_rootref['NEXT_PAGE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_NEXT'])) ? $this->_rootref['L_NEXT'] : ((isset($user->lang['NEXT'])) ? $user->lang['NEXT'] : '{ NEXT }')); ?></a>
			<?php } else { ?>

			&nbsp;
			<?php } ?>

		</li>
	</ul>
</form>
<?php } if ($this->_rootref['S_DISPLAY_POST_INFO'] || $this->_rootref['PAGINATION'] || $this->_rootref['TOTAL_POSTS'] || $this->_rootref['TOTAL_TOPICS']) {  ?>

<ul class="topic-actions clearfix">
	<?php if (! $this->_rootref['S_IS_BOT'] && $this->_rootref['S_DISPLAY_POST_INFO']) {  ?>

	<li class="lt">
		<span class="forumbutton rc5"><a class="gd3 rc5" href="<?php echo (isset($this->_rootref['U_POST_REPLY_TOPIC'])) ? $this->_rootref['U_POST_REPLY_TOPIC'] : ''; ?>" title="<?php if ($this->_rootref['S_IS_LOCKED']) {  echo ((isset($this->_rootref['L_TOPIC_LOCKED'])) ? $this->_rootref['L_TOPIC_LOCKED'] : ((isset($user->lang['TOPIC_LOCKED'])) ? $user->lang['TOPIC_LOCKED'] : '{ TOPIC_LOCKED }')); } else { echo ((isset($this->_rootref['L_POST_REPLY'])) ? $this->_rootref['L_POST_REPLY'] : ((isset($user->lang['POST_REPLY'])) ? $user->lang['POST_REPLY'] : '{ POST_REPLY }')); } ?>"><span><?php if ($this->_rootref['S_IS_LOCKED']) {  ?><strong>Locked</strong><?php } else { ?>Post<strong>Reply</strong><?php } ?></span></a></span>
	</li>
	<?php } if ($this->_rootref['PAGINATION'] || $this->_rootref['TOTAL_POSTS'] || $this->_rootref['TOTAL_TOPICS']) {  ?>

	<li class="rt">
		<ul class="paging nav list">
			<?php if (! $this->_rootref['S_IS_BOT'] && $this->_rootref['U_MARK_TOPICS']) {  ?>

			<li><a href="<?php echo (isset($this->_rootref['U_MARK_TOPICS'])) ? $this->_rootref['U_MARK_TOPICS'] : ''; ?>" accesskey="m"><?php echo ((isset($this->_rootref['L_MARK_TOPICS_READ'])) ? $this->_rootref['L_MARK_TOPICS_READ'] : ((isset($user->lang['MARK_TOPICS_READ'])) ? $user->lang['MARK_TOPICS_READ'] : '{ MARK_TOPICS_READ }')); ?></a>
			<?php } if ($this->_rootref['TOTAL_TOPICS']) {  ?>

			<li><?php echo (isset($this->_rootref['TOTAL_TOPICS'])) ? $this->_rootref['TOTAL_TOPICS'] : ''; ?></li>
			<?php } if ($this->_rootref['PAGE_NUMBER']) {  if ($this->_rootref['PAGINATION']) {  ?>

			<li><a href="#" class="jumpto" title="<?php echo ((isset($this->_rootref['L_JUMP_TO_PAGE'])) ? $this->_rootref['L_JUMP_TO_PAGE'] : ((isset($user->lang['JUMP_TO_PAGE'])) ? $user->lang['JUMP_TO_PAGE'] : '{ JUMP_TO_PAGE }')); ?>"><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></a></li>
			<li class="pages"><?php echo (isset($this->_rootref['PAGINATION'])) ? $this->_rootref['PAGINATION'] : ''; ?></li><!-- this needs rewritten into a list or separated into a loop --><?php } else { ?>

			<li><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></li>
				<?php } } ?>

		</ul>
	</li>
	<?php } ?>

</ul>
<?php } $this->_tpl_include('includes/jumpbox.html'); if ($this->_rootref['S_TOPIC_MOD']) {  ?>

<form class="clearfix" method="post" action="<?php echo (isset($this->_rootref['S_MOD_ACTION'])) ? $this->_rootref['S_MOD_ACTION'] : ''; ?>">
	<fieldset class="quickmod rt clearfix">
		<dl class="clearfix">
			<dt><label for="quick-mod-select"><?php echo ((isset($this->_rootref['L_QUICK_MOD'])) ? $this->_rootref['L_QUICK_MOD'] : ((isset($user->lang['QUICK_MOD'])) ? $user->lang['QUICK_MOD'] : '{ QUICK_MOD }')); ?> : </label><dt>	<dd><?php echo (isset($this->_rootref['S_TOPIC_MOD'])) ? $this->_rootref['S_TOPIC_MOD'] : ''; ?></dd>
																			<dd><input type="submit" value="<?php echo ((isset($this->_rootref['L_GO'])) ? $this->_rootref['L_GO'] : ((isset($user->lang['GO'])) ? $user->lang['GO'] : '{ GO }')); ?>" class="button2" /></dd>
		</dl>
		<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>

	</fieldset>
</form>
<?php } if ($this->_rootref['S_DISPLAY_ONLINE_LIST']) {  ?>

<div id="online_list" class="section online_list clearfix">
	<h3 class="h3b">
		<?php if ($this->_rootref['U_VIEWONLINE']) {  ?>

		<a href="<?php echo (isset($this->_rootref['U_VIEWONLINE'])) ? $this->_rootref['U_VIEWONLINE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_WHO_IS_ONLINE'])) ? $this->_rootref['L_WHO_IS_ONLINE'] : ((isset($user->lang['WHO_IS_ONLINE'])) ? $user->lang['WHO_IS_ONLINE'] : '{ WHO_IS_ONLINE }')); ?></a>
		<?php } else { ?>

		<?php echo ((isset($this->_rootref['L_WHO_IS_ONLINE'])) ? $this->_rootref['L_WHO_IS_ONLINE'] : ((isset($user->lang['WHO_IS_ONLINE'])) ? $user->lang['WHO_IS_ONLINE'] : '{ WHO_IS_ONLINE }')); ?>

		<?php } ?>

	</h3>
	<p><?php echo (isset($this->_rootref['LOGGED_IN_USER_LIST'])) ? $this->_rootref['LOGGED_IN_USER_LIST'] : ''; ?></p>
</div>
<?php } $this->_tpl_include('includes/overall_footer.html'); ?>