<?php if (!defined('IN_PHPBB')) exit; ?><form method="post" action="<?php echo (isset($this->_rootref['U_QR_ACTION'])) ? $this->_rootref['U_QR_ACTION'] : ''; ?>">
	<div id="qr_fulleditor" class="section qr_fulleditor rc5 bg6 clearfix">
		<div class="article clearfix">
			<h2 class="h2b"><?php echo ((isset($this->_rootref['L_QUICKREPLY'])) ? $this->_rootref['L_QUICKREPLY'] : ((isset($user->lang['QUICKREPLY'])) ? $user->lang['QUICKREPLY'] : '{ QUICKREPLY }')); ?></h2>
			<fieldset class="fields1">
				<dl class="clearfix">
					<dt><label for="subject"><?php echo ((isset($this->_rootref['L_SUBJECT'])) ? $this->_rootref['L_SUBJECT'] : ((isset($user->lang['SUBJECT'])) ? $user->lang['SUBJECT'] : '{ SUBJECT }')); ?>:</label></dt><dd><input type="text" name="subject" id="subject" size="45" maxlength="64" tabindex="2" value="<?php echo (isset($this->_rootref['SUBJECT'])) ? $this->_rootref['SUBJECT'] : ''; ?>" class="inputbox autowidth" /></dd>
				</dl>
				<dl class="message-box clearfix">
					<dd><textarea name="message" rows="7" cols="76" tabindex="3" class="inputbox"></textarea></dd>
				</dl>
				<dl class="clearfix submit-buttons">
					<dd><input type="submit" accesskey="s" tabindex="6" name="post" value="<?php echo ((isset($this->_rootref['L_SUBMIT'])) ? $this->_rootref['L_SUBMIT'] : ((isset($user->lang['SUBMIT'])) ? $user->lang['SUBMIT'] : '{ SUBMIT }')); ?>" class="button2" /></dd>
					<dd><input type="submit" accesskey="f" tabindex="7" name="full_editor" value="<?php echo ((isset($this->_rootref['L_FULL_EDITOR'])) ? $this->_rootref['L_FULL_EDITOR'] : ((isset($user->lang['FULL_EDITOR'])) ? $user->lang['FULL_EDITOR'] : '{ FULL_EDITOR }')); ?>" class="button2" /></dd>
				</dl>
				<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>

				<?php echo (isset($this->_rootref['QR_HIDDEN_FIELDS'])) ? $this->_rootref['QR_HIDDEN_FIELDS'] : ''; ?>

			</fieldset>
			<span id="qr_hide" class="qr_hide rt clearfix"><a href="#" title="<?php echo ((isset($this->_rootref['L_COLLAPSE_QR'])) ? $this->_rootref['L_COLLAPSE_QR'] : ((isset($user->lang['COLLAPSE_QR'])) ? $user->lang['COLLAPSE_QR'] : '{ COLLAPSE_QR }')); ?>"><?php echo ((isset($this->_rootref['L_COLLAPSE_QR'])) ? $this->_rootref['L_COLLAPSE_QR'] : ((isset($user->lang['COLLAPSE_QR'])) ? $user->lang['COLLAPSE_QR'] : '{ COLLAPSE_QR }')); ?></a></span>
		</div>
	</div>
	<div id="qr_showeditor" class="section qr_showeditor rc5 bg6 clearfix">
		<div class="article clearfix">
			<fieldset class="fields1">
				<dl class=" clearfix submit-buttons">
					<dd><input type="submit" id="qr_show" name="show_qr" tabindex="1" class="button2" value="<?php echo ((isset($this->_rootref['L_SHOW_QR'])) ? $this->_rootref['L_SHOW_QR'] : ((isset($user->lang['SHOW_QR'])) ? $user->lang['SHOW_QR'] : '{ SHOW_QR }')); ?>" /></dd>
				</dl>
			</fieldset>
		</div>
	</div>
</form>