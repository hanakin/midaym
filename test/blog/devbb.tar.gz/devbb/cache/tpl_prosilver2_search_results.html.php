<?php if (!defined('IN_PHPBB')) exit; $this->_tpl_include('includes/overall_header.html'); ?>

<h2>
	<?php if ($this->_rootref['SEARCH_TITLE']) {  ?>

	<?php echo (isset($this->_rootref['SEARCH_TITLE'])) ? $this->_rootref['SEARCH_TITLE'] : ''; ?>

	<?php } else { ?>

	<?php echo (isset($this->_rootref['SEARCH_MATCHES'])) ? $this->_rootref['SEARCH_MATCHES'] : ''; ?>

	<?php } if ($this->_rootref['SEARCH_WORDS']) {  ?>

	: <a href="<?php echo (isset($this->_rootref['U_SEARCH_WORDS'])) ? $this->_rootref['U_SEARCH_WORDS'] : ''; ?>"><?php echo (isset($this->_rootref['SEARCH_WORDS'])) ? $this->_rootref['SEARCH_WORDS'] : ''; ?></a>
	<?php } ?>

</h2>
<?php if ($this->_rootref['IGNORED_WORDS']) {  ?>

<p><?php echo ((isset($this->_rootref['L_IGNORED_TERMS'])) ? $this->_rootref['L_IGNORED_TERMS'] : ((isset($user->lang['IGNORED_TERMS'])) ? $user->lang['IGNORED_TERMS'] : '{ IGNORED_TERMS }')); ?>: <strong><?php echo (isset($this->_rootref['IGNORED_WORDS'])) ? $this->_rootref['IGNORED_WORDS'] : ''; ?></strong></p>
<?php } ?>

<form method="post" action="<?php echo (isset($this->_rootref['S_SEARCH_ACTION'])) ? $this->_rootref['S_SEARCH_ACTION'] : ''; ?>">
	<ul class="topic-actions clearfix">
		<li class="lt">
			<ul>
				<?php if ($this->_rootref['SEARCH_TOPIC']) {  ?>

				<li><a class="<?php echo (isset($this->_rootref['S_CONTENT_FLOW_BEGIN'])) ? $this->_rootref['S_CONTENT_FLOW_BEGIN'] : ''; ?>" href="<?php echo (isset($this->_rootref['U_SEARCH_TOPIC'])) ? $this->_rootref['U_SEARCH_TOPIC'] : ''; ?>"><?php echo ((isset($this->_rootref['L_RETURN_TO'])) ? $this->_rootref['L_RETURN_TO'] : ((isset($user->lang['RETURN_TO'])) ? $user->lang['RETURN_TO'] : '{ RETURN_TO }')); ?>: <?php echo (isset($this->_rootref['SEARCH_TOPIC'])) ? $this->_rootref['SEARCH_TOPIC'] : ''; ?></a></li>
				<?php } else { ?>

				<li class="return">
					<a class="<?php echo (isset($this->_rootref['S_CONTENT_FLOW_BEGIN'])) ? $this->_rootref['S_CONTENT_FLOW_BEGIN'] : ''; ?>" href="<?php echo (isset($this->_rootref['U_SEARCH'])) ? $this->_rootref['U_SEARCH'] : ''; ?>" title="<?php echo ((isset($this->_rootref['L_SEARCH_ADV'])) ? $this->_rootref['L_SEARCH_ADV'] : ((isset($user->lang['SEARCH_ADV'])) ? $user->lang['SEARCH_ADV'] : '{ SEARCH_ADV }')); ?>"><?php echo ((isset($this->_rootref['L_RETURN_TO_SEARCH_ADV'])) ? $this->_rootref['L_RETURN_TO_SEARCH_ADV'] : ((isset($user->lang['RETURN_TO_SEARCH_ADV'])) ? $user->lang['RETURN_TO_SEARCH_ADV'] : '{ RETURN_TO_SEARCH_ADV }')); ?></a>
				</li>
				<?php } ?>

			</ul>
		</li>
		<li class="rt">
			<ul class="nav list paging">
				<?php if (sizeof($this->_tpldata['searchresults'])) {  ?>

				<li><?php echo (isset($this->_rootref['SEARCH_MATCHES'])) ? $this->_rootref['SEARCH_MATCHES'] : ''; ?></li>
				<?php } if ($this->_rootref['PAGINATION']) {  ?>

				<li><a href="#" class="jumpto" title="<?php echo ((isset($this->_rootref['L_JUMP_TO_PAGE'])) ? $this->_rootref['L_JUMP_TO_PAGE'] : ((isset($user->lang['JUMP_TO_PAGE'])) ? $user->lang['JUMP_TO_PAGE'] : '{ JUMP_TO_PAGE }')); ?>"><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></a></li>
				<li class="pages"><?php echo (isset($this->_rootref['PAGINATION'])) ? $this->_rootref['PAGINATION'] : ''; ?></li>
				<?php } else { ?>

				<li><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></li>
				<?php } ?>

			</ul>
		</li>
	</ul>
</form>
<?php if ($this->_rootref['S_SHOW_TOPICS']) {  if (sizeof($this->_tpldata['searchresults'])) {  ?>

	<ol class="results">
		<li class="forum gd2 rc5">
			<ul class="topiclist">
				<li class="hd">
					<dl class="clearfix">
						<dt class="title g8"><?php echo ((isset($this->_rootref['L_TOPICS'])) ? $this->_rootref['L_TOPICS'] : ((isset($user->lang['TOPICS'])) ? $user->lang['TOPICS'] : '{ TOPICS }')); ?></dt>
						<dd class="posts g2 omega"><?php echo ((isset($this->_rootref['L_REPLIES'])) ? $this->_rootref['L_REPLIES'] : ((isset($user->lang['REPLIES'])) ? $user->lang['REPLIES'] : '{ REPLIES }')); ?></dd>
						<dd class="views g2 omega"><?php echo ((isset($this->_rootref['L_VIEWS'])) ? $this->_rootref['L_VIEWS'] : ((isset($user->lang['VIEWS'])) ? $user->lang['VIEWS'] : '{ VIEWS }')); ?></dd>
						<dd class="latest g3"><?php echo ((isset($this->_rootref['L_LAST_POST'])) ? $this->_rootref['L_LAST_POST'] : ((isset($user->lang['LAST_POST'])) ? $user->lang['LAST_POST'] : '{ LAST_POST }')); ?></dd>
					</dl>
				</li>
				<li class="bd">
					<ol class="rows">
						<?php $_searchresults_count = (isset($this->_tpldata['searchresults'])) ? sizeof($this->_tpldata['searchresults']) : 0;if ($_searchresults_count) {for ($_searchresults_i = 0; $_searchresults_i < $_searchresults_count; ++$_searchresults_i){$_searchresults_val = &$this->_tpldata['searchresults'][$_searchresults_i]; ?>

						<li class="row">
							<dl class="clearfix">
								<dt class="icon<?php if ($_searchresults_val['TOPIC_IMG_STYLE']) {  ?> <?php echo $_searchresults_val['TOPIC_IMG_STYLE']; } ?>"><dfn class="<?php echo $_searchresults_val['TOPIC_ICON_IMG']; ?>"><?php echo $_searchresults_val['TOPIC_FOLDER_IMG_ALT']; ?></dfn></dt>
								<dt class="title g8 alpha">
									<div class="hgroup g16">
										<h3>
											<?php if ($_searchresults_val['S_UNREAD_TOPIC']) {  ?>

											<a class="newpost-icon" href="<?php echo $_searchresults_val['U_NEWEST_POST']; ?>">View First Unread Post</a> 
											<?php } ?>

											<a href="<?php echo $_searchresults_val['U_VIEW_TOPIC']; ?>" class="topictitle"><?php echo $_searchresults_val['TOPIC_TITLE']; ?></a>
											<?php if ($_searchresults_val['S_TOPIC_UNAPPROVED'] || $_searchresults_val['S_POSTS_UNAPPROVED']) {  ?>

											<a class="unapproved-icon" href="<?php echo $_searchresults_val['U_MCP_QUEUE']; ?>">Unapproved</a>  
											<?php } if ($_searchresults_val['S_TOPIC_REPORTED']) {  ?>

											<a class="reported-icon" href="<?php echo $_searchresults_val['U_MCP_REPORT']; ?>">Reported</a>
											<?php } ?>

										</h3>
										<cite>
											<?php if ($_searchresults_val['ATTACH_ICON_IMG']) {  ?>

											<em class="attachment-icon">Attachments(s)</em> 
											<?php } ?>

											<span><?php echo ((isset($this->_rootref['L_POST_BY_AUTHOR'])) ? $this->_rootref['L_POST_BY_AUTHOR'] : ((isset($user->lang['POST_BY_AUTHOR'])) ? $user->lang['POST_BY_AUTHOR'] : '{ POST_BY_AUTHOR }')); ?> <?php echo $_searchresults_val['TOPIC_AUTHOR_FULL']; ?> &raquo; </span>
											<span class="time"><?php echo $_searchresults_val['FIRST_POST_TIME']; ?></span>
											<?php if (! $_searchresults_val['S_TOPIC_GLOBAL']) {  ?>

											<span><?php echo ((isset($this->_rootref['L_IN'])) ? $this->_rootref['L_IN'] : ((isset($user->lang['IN'])) ? $user->lang['IN'] : '{ IN }')); ?> <a href="<?php echo $_searchresults_val['U_VIEW_FORUM']; ?>"><?php echo $_searchresults_val['FORUM_TITLE']; ?></a></span>
											<?php } else { ?>

											<span>(<?php echo ((isset($this->_rootref['L_GLOBAL'])) ? $this->_rootref['L_GLOBAL'] : ((isset($user->lang['GLOBAL'])) ? $user->lang['GLOBAL'] : '{ GLOBAL }')); ?>)</span>
											<?php } ?>

										</cite>
										<?php if ($_searchresults_val['PAGINATION']) {  ?>

										<span class="pages"><?php echo $_searchresults_val['PAGINATION']; ?></span>
										<?php } ?>

									</div>
								</dt>
								<dd class="posts g2 alpha omega"><?php echo $_searchresults_val['TOPIC_REPLIES']; ?></dd>
								<dd class="views g2 alpha omega"><?php echo $_searchresults_val['TOPIC_VIEWS']; ?></dd>
								<dd class="latest g3 alpha">
									<cite>
										<span>
											<?php echo ((isset($this->_rootref['L_POST_BY_AUTHOR'])) ? $this->_rootref['L_POST_BY_AUTHOR'] : ((isset($user->lang['POST_BY_AUTHOR'])) ? $user->lang['POST_BY_AUTHOR'] : '{ POST_BY_AUTHOR }')); ?> <?php echo $_searchresults_val['LAST_POST_AUTHOR_FULL']; ?> 
											<?php if (! $this->_rootref['S_IS_BOT']) {  ?>

											<a class="latestpost-icon" href="<?php echo $_searchresults_val['U_LAST_POST']; ?>">View the latest post</a>  
											<?php } ?>

										</span>
										<span class="time"><?php echo $_searchresults_val['LAST_POST_TIME']; ?></span>
									</cite>
								</dd>
							</dl>
						</li>
						<?php }} ?>

					</ol>
				<li>
			</ul>
		</li>
	</ol>
	<?php } else { ?>

	<div class="section">
		<div class="article clearfix">
			<strong><?php echo ((isset($this->_rootref['L_NO_SEARCH_RESULTS'])) ? $this->_rootref['L_NO_SEARCH_RESULTS'] : ((isset($user->lang['NO_SEARCH_RESULTS'])) ? $user->lang['NO_SEARCH_RESULTS'] : '{ NO_SEARCH_RESULTS }')); ?></strong>
		</div>
	</div>
	<?php } } else { ?>

	<ol class="results">
	<?php $_searchresults_count = (isset($this->_tpldata['searchresults'])) ? sizeof($this->_tpldata['searchresults']) : 0;if ($_searchresults_count) {for ($_searchresults_i = 0; $_searchresults_i < $_searchresults_count; ++$_searchresults_i){$_searchresults_val = &$this->_tpldata['searchresults'][$_searchresults_i]; ?>

		<li class="result">
			<div class="section search post<?php if ($_searchresults_val['S_POST_REPORTED']) {  ?> reported<?php } ?> rc5 clearfix">
				<div class="article clearfix">
					<?php if ($_searchresults_val['S_IGNORE_POST']) {  ?>

					<div class="postbody">
						<?php echo $_searchresults_val['L_IGNORE_POST']; ?>

					</div>
					<?php } else { ?>

					<div class="aside lt postbody g12">
						<h3><a href="<?php echo $_searchresults_val['U_VIEW_POST']; ?>"><?php echo $_searchresults_val['POST_SUBJECT']; ?></a></h3>
						<div class="content"><?php echo $_searchresults_val['MESSAGE']; ?></div>
					</div>
					<div class="aside rt profile g4 omega">
						<span class="postprofile">
							<dl class="clearfix">
								<dd class="author"><?php echo ((isset($this->_rootref['L_POST_BY_AUTHOR'])) ? $this->_rootref['L_POST_BY_AUTHOR'] : ((isset($user->lang['POST_BY_AUTHOR'])) ? $user->lang['POST_BY_AUTHOR'] : '{ POST_BY_AUTHOR }')); ?> <?php echo $_searchresults_val['POST_AUTHOR_FULL']; ?></dd>
							</dl>
							<dl class="clearfix">
								<dd><span class="time"><?php echo $_searchresults_val['POST_DATE']; ?></span></dd>
							</dl>
							<dl class="clearfix">
								<dt>&nbsp;</dt>
							</dl>
							<?php if ($_searchresults_val['FORUM_TITLE']) {  ?>

							<dl class="details clearfix">
								<dt><?php echo ((isset($this->_rootref['L_FORUM'])) ? $this->_rootref['L_FORUM'] : ((isset($user->lang['FORUM'])) ? $user->lang['FORUM'] : '{ FORUM }')); ?>: </dt><dd><a href="<?php echo $_searchresults_val['U_VIEW_FORUM']; ?>"><?php echo $_searchresults_val['FORUM_TITLE']; ?></a></dd>
							</dl>
							<dl class="details clearfix">
								<dt><?php echo ((isset($this->_rootref['L_TOPIC'])) ? $this->_rootref['L_TOPIC'] : ((isset($user->lang['TOPIC'])) ? $user->lang['TOPIC'] : '{ TOPIC }')); ?>: </dt><dd><a href="<?php echo $_searchresults_val['U_VIEW_TOPIC']; ?>"><?php echo $_searchresults_val['TOPIC_TITLE']; ?></a></dd>
							</dl>
							<?php } else { ?>

							<dl class="details clearfix">
								<dt><?php echo ((isset($this->_rootref['L_GLOBAL'])) ? $this->_rootref['L_GLOBAL'] : ((isset($user->lang['GLOBAL'])) ? $user->lang['GLOBAL'] : '{ GLOBAL }')); ?>: </dt><dd><a href="<?php echo $_searchresults_val['U_VIEW_TOPIC']; ?>"><?php echo $_searchresults_val['TOPIC_TITLE']; ?></a></dd>
							</dl>
							<?php } ?>

							<dl class="details clearfix">
								<dt><?php echo ((isset($this->_rootref['L_REPLIES'])) ? $this->_rootref['L_REPLIES'] : ((isset($user->lang['REPLIES'])) ? $user->lang['REPLIES'] : '{ REPLIES }')); ?>: </dt><dd><?php echo $_searchresults_val['TOPIC_REPLIES']; ?></dd>
							</dl>
							<dl class="clearfix">
								<dt><?php echo ((isset($this->_rootref['L_VIEWS'])) ? $this->_rootref['L_VIEWS'] : ((isset($user->lang['VIEWS'])) ? $user->lang['VIEWS'] : '{ VIEWS }')); ?>: </dt><dd><?php echo $_searchresults_val['TOPIC_VIEWS']; ?></dd>
							</dl>
						</span>
					</div>
					<?php } if (! $_searchresults_val['S_IGNORE_POST']) {  ?>

					<span class="jump rt clearfix">
						<a href="<?php echo $_searchresults_val['U_VIEW_POST']; ?>" class="<?php echo (isset($this->_rootref['S_CONTENT_FLOW_END'])) ? $this->_rootref['S_CONTENT_FLOW_END'] : ''; ?>"><?php echo ((isset($this->_rootref['L_JUMP_TO_POST'])) ? $this->_rootref['L_JUMP_TO_POST'] : ((isset($user->lang['JUMP_TO_POST'])) ? $user->lang['JUMP_TO_POST'] : '{ JUMP_TO_POST }')); ?></a>
					</span>
					<?php } ?>

				</div>
			</div>
		<li>
	<?php }} else { ?>

	<div class="section">
		<div class="article clearfix">
			<strong><?php echo ((isset($this->_rootref['L_NO_SEARCH_RESULTS'])) ? $this->_rootref['L_NO_SEARCH_RESULTS'] : ((isset($user->lang['NO_SEARCH_RESULTS'])) ? $user->lang['NO_SEARCH_RESULTS'] : '{ NO_SEARCH_RESULTS }')); ?></strong>
		</div>
	</div>
	<?php } } if ($this->_rootref['PAGINATION'] || sizeof($this->_tpldata['searchresults']) || $this->_rootref['S_SELECT_SORT_KEY'] || $this->_rootref['S_SELECT_SORT_DAYS']) {  ?>

	<form method="post" action="<?php echo (isset($this->_rootref['S_SEARCH_ACTION'])) ? $this->_rootref['S_SEARCH_ACTION'] : ''; ?>">
		<ul class="display-options clearfix">
			<li class="lt prev g1 alpha">
				<?php if ($this->_rootref['PREVIOUS_PAGE']) {  ?>

				<a href="<?php echo (isset($this->_rootref['PREVIOUS_PAGE'])) ? $this->_rootref['PREVIOUS_PAGE'] : ''; ?>" class="prev"><?php echo ((isset($this->_rootref['L_PREVIOUS'])) ? $this->_rootref['L_PREVIOUS'] : ((isset($user->lang['PREVIOUS'])) ? $user->lang['PREVIOUS'] : '{ PREVIOUS }')); ?></a>
				<?php } else { ?>

				&nbsp;
				<?php } ?>

			</li>
			<?php if ($this->_rootref['S_SELECT_SORT_DAYS'] || $this->_rootref['S_SELECT_SORT_KEY']) {  ?>

			<li class="cn g14">	
				<fieldset>
					<dl class="clearfix">
						<?php if ($this->_rootref['S_SHOW_TOPICS']) {  ?>

						<dt><label><?php echo ((isset($this->_rootref['L_DISPLAY_POSTS'])) ? $this->_rootref['L_DISPLAY_POSTS'] : ((isset($user->lang['DISPLAY_POSTS'])) ? $user->lang['DISPLAY_POSTS'] : '{ DISPLAY_POSTS }')); ?>: </label></dt>
						<?php } else { ?>

						<dt><label><?php echo ((isset($this->_rootref['L_SORT_BY'])) ? $this->_rootref['L_SORT_BY'] : ((isset($user->lang['SORT_BY'])) ? $user->lang['SORT_BY'] : '{ SORT_BY }')); ?>: </label></dt>
						<dd><?php echo (isset($this->_rootref['S_SELECT_SORT_DAYS'])) ? $this->_rootref['S_SELECT_SORT_DAYS'] : ''; ?></dd>
						<?php if ($this->_rootref['S_SELECT_SORT_KEY']) {  ?>

						<dd><?php echo (isset($this->_rootref['S_SELECT_SORT_KEY'])) ? $this->_rootref['S_SELECT_SORT_KEY'] : ''; ?></dd>
						<dd><?php echo (isset($this->_rootref['S_SELECT_SORT_DIR'])) ? $this->_rootref['S_SELECT_SORT_DIR'] : ''; ?></dd>
						<?php } ?>

						<dd><input type="submit" name="sort" value="<?php echo ((isset($this->_rootref['L_GO'])) ? $this->_rootref['L_GO'] : ((isset($user->lang['GO'])) ? $user->lang['GO'] : '{ GO }')); ?>" class="button2" /></dd>
					</dl>
				</fieldset>
			</li>
			<?php } ?>

			<li class="rt next g1 omega">
				<?php if ($this->_rootref['NEXT_PAGE']) {  ?>

				<a href="<?php echo (isset($this->_rootref['NEXT_PAGE'])) ? $this->_rootref['NEXT_PAGE'] : ''; ?>"><?php echo ((isset($this->_rootref['L_NEXT'])) ? $this->_rootref['L_NEXT'] : ((isset($user->lang['NEXT'])) ? $user->lang['NEXT'] : '{ NEXT }')); ?></a>
				<?php } else { ?>

				&nbsp;
				<?php } ?>

			</li>
		</ul>
	</form>
<?php } if ($this->_rootref['PAGINATION'] || sizeof($this->_tpldata['searchresults']) || $this->_rootref['PAGE_NUMBER']) {  ?>

	<ul class="linklist clearfix">
		<li class="rt">
			<ul class="nav list paging">
				<?php if (sizeof($this->_tpldata['searchresults'])) {  ?>

				<li><?php echo (isset($this->_rootref['SEARCH_MATCHES'])) ? $this->_rootref['SEARCH_MATCHES'] : ''; ?></li>
				<?php } if ($this->_rootref['PAGINATION']) {  ?>

				<li><a href="#" class="jumpto" title="<?php echo ((isset($this->_rootref['L_JUMP_TO_PAGE'])) ? $this->_rootref['L_JUMP_TO_PAGE'] : ((isset($user->lang['JUMP_TO_PAGE'])) ? $user->lang['JUMP_TO_PAGE'] : '{ JUMP_TO_PAGE }')); ?>"><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></a></li>
				<li class="pages"><?php echo (isset($this->_rootref['PAGINATION'])) ? $this->_rootref['PAGINATION'] : ''; ?></li>
				<?php } else { ?>

				<li><?php echo (isset($this->_rootref['PAGE_NUMBER'])) ? $this->_rootref['PAGE_NUMBER'] : ''; ?></li>
				<?php } ?>

			</ul>
		</li>
	</ul>
<?php } $this->_tpl_include('includes/jumpbox.html'); $this->_tpl_include('includes/overall_footer.html'); ?>