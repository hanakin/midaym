<?php if (!defined('IN_PHPBB')) exit; ?><form method="post" action="<?php echo (isset($this->_rootref['S_POLL_ACTION'])) ? $this->_rootref['S_POLL_ACTION'] : ''; ?>">
	<div id="poll" class="section poll bg6 rc5"><!-- #NOTE Consider major redesign this is F-ugly -->
		<div class="article clearfix">
			<div class="hgroup hd">
				<h2 class="h2b"><?php echo (isset($this->_rootref['POLL_QUESTION'])) ? $this->_rootref['POLL_QUESTION'] : ''; ?></h2>
				<span class="author">
					<?php echo ((isset($this->_rootref['L_POLL_LENGTH'])) ? $this->_rootref['L_POLL_LENGTH'] : ((isset($user->lang['POLL_LENGTH'])) ? $user->lang['POLL_LENGTH'] : '{ POLL_LENGTH }')); ?>

					<?php if ($this->_rootref['S_CAN_VOTE'] && $this->_rootref['L_POLL_LENGTH']) {  ?>

					<br />
					<?php } if ($this->_rootref['S_CAN_VOTE']) {  ?>

					<?php echo ((isset($this->_rootref['L_MAX_VOTES'])) ? $this->_rootref['L_MAX_VOTES'] : ((isset($user->lang['MAX_VOTES'])) ? $user->lang['MAX_VOTES'] : '{ MAX_VOTES }')); ?>

					<?php } ?>

				</span>
			</div>	
			<ol class="poll-options bd clearfix">
				<?php $_poll_option_count = (isset($this->_tpldata['poll_option'])) ? sizeof($this->_tpldata['poll_option']) : 0;if ($_poll_option_count) {for ($_poll_option_i = 0; $_poll_option_i < $_poll_option_count; ++$_poll_option_i){$_poll_option_val = &$this->_tpldata['poll_option'][$_poll_option_i]; ?>

					<li class="poll-option">
						<dl class="clearfix">
							<dt class="g5 alpha">
								<?php if ($this->_rootref['S_CAN_VOTE']) {  ?>

								<label for="vote_<?php echo $_poll_option_val['POLL_OPTION_ID']; ?>"><?php echo $_poll_option_val['POLL_OPTION_CAPTION']; ?></label>
								<?php } else { ?>

								<?php echo $_poll_option_val['POLL_OPTION_CAPTION']; ?>

								<?php } ?>

							</dt>
							<?php if ($this->_rootref['S_CAN_VOTE']) {  ?>

							<dd class="checkbox g2">
								<?php if ($this->_rootref['S_IS_MULTI_CHOICE']) {  ?>

								<input type="checkbox" name="vote_id[]" id="vote_<?php echo $_poll_option_val['POLL_OPTION_ID']; ?>" value="<?php echo $_poll_option_val['POLL_OPTION_ID']; ?>"<?php if ($_poll_option_val['POLL_OPTION_VOTED']) {  ?> checked="checked"<?php } ?> />
								<?php } else { ?>

								<input type="radio" name="vote_id[]" id="vote_<?php echo $_poll_option_val['POLL_OPTION_ID']; ?>" value="<?php echo $_poll_option_val['POLL_OPTION_ID']; ?>"<?php if ($_poll_option_val['POLL_OPTION_VOTED']) {  ?> checked="checked"<?php } ?> />
								<?php } ?>

							</dd>
							<?php } if ($this->_rootref['S_DISPLAY_RESULTS']) {  ?>

							<dd class="resultbar g9">
								<div class="<?php if ($_poll_option_val['POLL_OPTION_PCT'] < (20)) {  ?>pb1<?php } else if ($_poll_option_val['POLL_OPTION_PCT'] < (40)) {  ?>pb2<?php } else if ($_poll_option_val['POLL_OPTION_PCT'] < (60)) {  ?>pb3<?php } else if ($_poll_option_val['POLL_OPTION_PCT'] < (80)) {  ?>pb4<?php } else { ?>pb5<?php } ?>" style="width:<?php echo $_poll_option_val['POLL_OPTION_PERCENT']; ?>;"><?php echo $_poll_option_val['POLL_OPTION_RESULT']; ?></div>
							</dd>
							<dd class="g2 <?php if ($_poll_option_val['POLL_OPTION_VOTED']) {  ?>voted<?php } ?>"<?php if ($_poll_option_val['POLL_OPTION_VOTED']) {  ?> title="<?php echo ((isset($this->_rootref['L_POLL_VOTED_OPTION'])) ? $this->_rootref['L_POLL_VOTED_OPTION'] : ((isset($user->lang['POLL_VOTED_OPTION'])) ? $user->lang['POLL_VOTED_OPTION'] : '{ POLL_VOTED_OPTION }')); ?>"<?php } ?>>
								<?php if ($_poll_option_val['POLL_OPTION_RESULT'] == 0) {  ?>

								<?php echo ((isset($this->_rootref['L_NO_VOTES'])) ? $this->_rootref['L_NO_VOTES'] : ((isset($user->lang['NO_VOTES'])) ? $user->lang['NO_VOTES'] : '{ NO_VOTES }')); ?>

								<?php } else { ?>

								<?php echo $_poll_option_val['POLL_OPTION_PERCENT']; ?>

								<?php } ?>

							</dd>
						<?php } ?>

						</dl>
					</li>
				<?php }} ?>

			</ol>
			<div class="ft clearfix">
				<?php if ($this->_rootref['S_DISPLAY_RESULTS']) {  ?>

				<p><?php echo ((isset($this->_rootref['L_TOTAL_VOTES'])) ? $this->_rootref['L_TOTAL_VOTES'] : ((isset($user->lang['TOTAL_VOTES'])) ? $user->lang['TOTAL_VOTES'] : '{ TOTAL_VOTES }')); ?> : <?php echo (isset($this->_rootref['TOTAL_VOTES'])) ? $this->_rootref['TOTAL_VOTES'] : ''; ?></p>
				<?php } if ($this->_rootref['S_CAN_VOTE']) {  ?>

				<input type="submit" name="update" value="<?php echo ((isset($this->_rootref['L_SUBMIT_VOTE'])) ? $this->_rootref['L_SUBMIT_VOTE'] : ((isset($user->lang['SUBMIT_VOTE'])) ? $user->lang['SUBMIT_VOTE'] : '{ SUBMIT_VOTE }')); ?>" class="button2" />
				<?php } if (! $this->_rootref['S_DISPLAY_RESULTS']) {  ?>

				<a class="button2" href="<?php echo (isset($this->_rootref['U_VIEW_RESULTS'])) ? $this->_rootref['U_VIEW_RESULTS'] : ''; ?>"><?php echo ((isset($this->_rootref['L_VIEW_RESULTS'])) ? $this->_rootref['L_VIEW_RESULTS'] : ((isset($user->lang['VIEW_RESULTS'])) ? $user->lang['VIEW_RESULTS'] : '{ VIEW_RESULTS }')); ?></a>
				<?php } ?>

				<?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?>

				<?php echo (isset($this->_rootref['S_HIDDEN_FIELDS'])) ? $this->_rootref['S_HIDDEN_FIELDS'] : ''; ?>

			</div>
		</div>
	</div>
</form>
<hr />