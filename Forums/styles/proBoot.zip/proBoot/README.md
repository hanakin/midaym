proBoot
=======

phpBB3 theme based on [Bootstrap](http://twitter.github.com/bootstrap/) framework.

**Base style:** proSilver

**Style Version:** *In Development*

**phpBB version:** phpBB 3.0.x-3.1.0

**Demo:** *Coming soon*

**Download:** [http://shibulijack.github.com/proBoot/](http://shibulijack.github.com/proBoot/)

**Blog post:** [http://shibulijack.wordpress.com/2012/12/06/proboot-bootstrap-theme-for-phpbb3](http://shibulijack.wordpress.com/2012/12/06/proboot-bootstrap-theme-for-phpbb3)